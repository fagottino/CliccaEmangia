var express = require('express');
var app = express();

console.log('E\' lui');
    
app.get('/', function () {
    console.log('Eccolooooo');
});

app.listen(8080);